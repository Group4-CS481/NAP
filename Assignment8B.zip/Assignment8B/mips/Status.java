package mips;

public enum Status
{
    SUCCESS,
    UNSUPPORTED,
    FILE_NOT_FOUND,
    IO_ERROR,
    RESOURCES_ERROR
}
